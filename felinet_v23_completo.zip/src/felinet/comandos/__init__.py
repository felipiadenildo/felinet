"""Subcomandos do CLI felinet."""
