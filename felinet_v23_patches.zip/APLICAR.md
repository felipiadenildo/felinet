# APLICAR — felinet v23 release candidate

Pacote de patches gerado a partir da branch `refactor/v23-release-candidate`
sobre `refactor/layout-runs` SHA `8018baf`. Contém apenas os arquivos
*alterados* ou *novos* desde o `8018baf`, com a árvore de diretórios
preservada relativa à raiz do repo.

## Como aplicar

A partir do clone local do repo, com working tree limpo e checkout em
`refactor/layout-runs`:

```bash
cd ~/projetos/tcc-gatos-campus2
git checkout -b refactor/v23-release-candidate refactor/layout-runs

# 1. Sobrescrever / criar os arquivos alterados:
unzip -o /caminho/felinet_v23_patches.zip -d /tmp/v23patches
rsync -av --exclude APLICAR.md /tmp/v23patches/ .

# 2. Mover (git mv) as pastas que foram para quarentena:
mkdir -p _quarentena
git mv entrega _quarentena/entrega
git mv reports _quarentena/reports

# 3. Deletar a pasta felinet_runs_patch (patch ja aplicado):
git rm -r felinet_runs_patch/

# 4. Force-add do README de quarentena (gitignored para novos itens):
git add -f _quarentena/README.md

# 5. Adicionar e commitar tudo:
git add -A
git commit -m "feat: v23 release candidate"

# 6. Validar:
make instalar
make qualidade   # deve passar 100% (159 testes)
felinet --version  # deve mostrar 0.3.0
```

## Arquivos contidos neste ZIP

### Novos (criados nesta release)

```
.pre-commit-config.yaml
_quarentena/README.md
_quarentena/entrega/.gitkeep
_quarentena/entrega/README.md
_quarentena/reports/.gitkeep
_quarentena/reports/README.md
configs/datasets_locais.example.yaml
docs/ARQUITETURA.md
docs/DATASETS.md
docs/DEBUGGING.md
docs/REPRODUCAO_MONOGRAFIA.md
docs/governanca/MIGRACAO_v22_para_v23.md
src/felinet/comandos/easyrun.py
src/felinet/datasets/iteradores.py
src/felinet/datasets/registro.py
src/felinet/pipeline/dev_visual.py
tests/test_comandos_datasets_linkar.py
tests/test_comandos_figuras_bloco7.py
tests/test_comandos_figuras_bloco9.py
tests/test_datasets_iteradores.py
tests/test_datasets_registro.py
tests/test_easyrun.py
tests/test_hotfix_amostragem_resolver.py
tests/test_modo_dev.py
```

### Modificados (substituem os existentes)

```
.gitignore
Makefile
README.md
pyproject.toml
src/felinet/__init__.py
src/felinet/cli.py
src/felinet/comandos/datasets.py
src/felinet/comandos/dev.py
src/felinet/comandos/figuras.py
src/felinet/comandos/pipeline.py
src/felinet/config.py
src/felinet/pipeline/fase1_ingestao/manifesto.py
src/felinet/pipeline/orquestrador.py
tests/test_datasets_felidae.py
```

### Removidos (deletar manualmente após aplicar o ZIP)

```
felinet_runs_patch/                  (pasta inteira — git rm -r)
entrega/                             (movida para _quarentena/entrega/)
reports/                             (movida para _quarentena/reports/)
```

## Validação do commit final

Após o commit, o `git log --oneline refactor/layout-runs..HEAD` deve
mostrar exatamente 10 entradas (ou uma única se aplicado em squash).
A sequência por blocos foi:

1. `fix(pipeline)` — hotfix smoke (resolver dict, max-amostras, manifesto).
2. `feat(figuras)` — Bloco 7 comparativo-fontes.
3. `feat(datasets)` — registro local + linkar/listar.
4. `feat(pipeline)` — modo --dev + comando demo.
5. `feat(cli)` — easyrun wizard.
6. `feat(figuras)` — Bloco 9 esqueleto.
7. `refactor` — remover felinet_runs_patch + quarentena.
8. `docs` — README + 5 docs novos.
9. `build` — pre-commit.
10. `chore` — bump 0.3.0.

## Nova dependência

`questionary >= 2.0` foi adicionada ao bloco principal de
`pyproject.toml`. Para instalar manualmente (caso o `make instalar`
não rode):

```bash
pip install 'questionary>=2.0'
```
