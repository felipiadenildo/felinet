# _quarentena

Arquivos suspeitos de obsolescência, removidos do código ativo mas mantidos
para revisão antes de deleção definitiva. Pasta versionada parcialmente:
materiais que entrarem aqui via ``git mv`` permanecem rastreados (para
rastreabilidade da movimentação); arquivos novos criados aqui ficam
gitignored.

Cada arquivo aqui tem o motivo registrado em
``docs/governanca/MIGRACAO_v22_para_v23.md``.

## Política

Conteúdo em quarentena por mais de uma release pode ser deletado em bloco
via ``git rm -r _quarentena/<sub>``. Antes de remover, conferir que nenhum
módulo ativo o referencia.
